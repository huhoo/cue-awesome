# 北辰股份有限公司（600001.SH）公开信息预尽调清单 · 窗口 2023-09-21~2026-09-21

> 本页为 AI 初稿，依据公开披露与法定原文整理，不构成投资建议，也不构成法律意见；判断位 [待人工]。

- subject: 北辰股份有限公司（600001.SH）
- asof: 2026-09-21
- lookback: 36m
- purpose: investment

| 日期 | 类目 | 事实(≤40字,只写披露所载) | 影响档位 | 状态 | 窗外余档 | 来源锚 |
|---|---|---|---|---|---|---|

本节检索域: regulatory_cn、entity_data、disclosure_cn、fr_fact_index、ipo 5 域 / 无工具项: 0

类目账龄申报: requested=2023-09-21~2026-09-21 | disclosure_cn=365d | beyond=未按类目互校
